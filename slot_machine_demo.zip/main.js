const reel1 = document.getElementById("reel1");
const reel2 = document.getElementById("reel2");
const reel3 = document.getElementById("reel3");

const resultText = document.getElementById("resultText");
const spinBtn = document.getElementById("spinBtn");

const spinSound = document.getElementById("spinSound");
const winSound = document.getElementById("winSound");

const symbols = ["🍒", "🍋", "⭐", "🔥"];

function spinReel() {
    return symbols[Math.floor(Math.random() * symbols.length)];
}

function clearEffects() {
    reel1.classList.remove("win");
    reel2.classList.remove("win");
    reel3.classList.remove("win");
}

spinBtn.addEventListener("click", () => {
    clearEffects();
    spinBtn.disabled = true;
    resultText.textContent = "กำลังหมุน…";

    spinSound.play();

    setTimeout(() => {
        const r1 = spinReel();
        const r2 = spinReel();
        const r3 = spinReel();

        reel1.textContent = r1;
        reel2.textContent = r2;
        reel3.textContent = r3;

        if (r1 === r2 && r2 === r3) {
            winSound.play();
            reel1.classList.add("win");
            reel2.classList.add("win");
            reel3.classList.add("win");

            let multiplier = 0;
            if (r1 === "🍒") multiplier = 10;
            if (r1 === "🍋") multiplier = 20;
            if (r1 === "⭐") multiplier = 50;
            if (r1 === "🔥") multiplier = 200;

            resultText.textContent = `🎉 ชนะ! คุณได้ x${multiplier}`;
        } else {
            resultText.textContent = "❌ ไม่ชนะ ลองใหม่อีกครั้ง!";
        }

        spinBtn.disabled = false;
    }, 1000);
});
